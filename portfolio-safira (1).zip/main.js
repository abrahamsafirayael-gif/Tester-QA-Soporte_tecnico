/* Arma el sitio a partir de content.js.
   - Cambia de idioma ES/EN en la misma página y la misma pestaña (sin recargar ni abrir ventanas).
   - Modo edición: abrí el sitio con  ?edit  al final de la dirección, hacé clic en cualquier texto,
     cambialo y descargá el content.js actualizado. Los visitantes nunca ven este modo. */
(function () {
  "use strict";

  var SITE = window.SITE;
  var cfg = SITE.config;
  var LANGS = ["en", "es"];
  var IDS = ["about", "how", "why", "background", "projects", "contact"];
  var DRAFT_KEY = "portfolio-draft-v1";
  var main = document.getElementById("main");
  var nav = document.getElementById("nav");
  var langBtn = document.getElementById("lang");
  var observer = null, rotTimer = null;
  var editing = new URLSearchParams(location.search).has("edit");
  var D = null;

  /* ---------- textos del editor ---------- */
  var UI = {
    en: {
      hint: "Click any text to edit it. Lists separated with  |  . Use the EN/ES button to edit the other language.",
      download: "Download content.js", discard: "Discard changes", saved: "Draft saved in this browser",
      downloaded: "Downloaded. Upload it to GitHub replacing the old content.js",
      confirmDiscard: "Discard all unsaved changes?",
      linksTitle: "Links and email (same for both languages)",
      email: "Email", github: "GitHub", linkedin: "LinkedIn", store: "Tienda Nube site",
      band: "Animated band. Separate with |", tags: "Tags. Separate with |", url: "Project link",
      add: "Add", remove: "Remove", note: "Highlighted note (optional)", status: "Status (optional)"
    },
    es: {
      hint: "Hacé clic en cualquier texto para editarlo. Listas separadas con  |  . Usá el botón EN/ES para editar el otro idioma.",
      download: "Descargar content.js", discard: "Descartar cambios", saved: "Borrador guardado en este navegador",
      downloaded: "Descargado. Subilo a GitHub reemplazando el content.js anterior",
      confirmDiscard: "¿Descartar todos los cambios sin descargar?",
      linksTitle: "Links y correo (iguales para los dos idiomas)",
      email: "Correo", github: "GitHub", linkedin: "LinkedIn", store: "Sitio de Tienda Nube",
      band: "Cinta animada. Separá con |", tags: "Etiquetas. Separá con |", url: "Link del proyecto",
      add: "Agregar", remove: "Eliminar", note: "Nota destacada (opcional)", status: "Estado (opcional)"
    }
  };
  var TPL = {
    en: {
      para: "New paragraph.",
      skill: { title: "New group", text: "Description." },
      job: { date: "Mon YYYY – Mon YYYY", duration: "Duration", type: "Work type", title: "Role", org: "Company · Place", bullets: ["Describe an achievement."], note: "" },
      edu: { date: "Year", status: "", title: "Title", org: "Institution" },
      project: { name: "New project", status: "", tags: ["Tag"], text: "Project description." },
      bullet: "New point."
    },
    es: {
      para: "Nuevo párrafo.",
      skill: { title: "Nuevo grupo", text: "Descripción." },
      job: { date: "Mes AAAA – Mes AAAA", duration: "Duración", type: "Modalidad", title: "Puesto", org: "Empresa · Lugar", bullets: ["Describí un logro."], note: "" },
      edu: { date: "Año", status: "", title: "Título", org: "Institución" },
      project: { name: "Nuevo proyecto", status: "", tags: ["Etiqueta"], text: "Descripción del proyecto." },
      bullet: "Nuevo punto."
    }
  };

  /* ---------- utilidades ---------- */
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function safeUrl(u) { return /^(https?:|mailto:|#)/i.test(u || "") ? u : ""; }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  // Rutas: "about.title"  (idioma actual)   |   "@github"  (links compartidos)
  function resolve(p) { return p.charAt(0) === "@" ? [cfg, p.slice(1)] : [D, p]; }
  function get(p) {
    var r = resolve(p), o = r[0];
    r[1].split(".").forEach(function (k) { o = o[k]; });
    return o;
  }
  function set(p, v) {
    var r = resolve(p), ks = r[1].split("."), last = ks.pop(), o = r[0];
    ks.forEach(function (k) { if (o[k] == null) o[k] = {}; o = o[k]; });
    o[last] = v;
  }

  /* Texto: normal para visitantes, editable en modo edición */
  function T(p, tag, cls) {
    var v = esc(get(p));
    if (!editing) return tag ? "<" + tag + (cls ? ' class="' + cls + '"' : "") + ">" + v + "</" + tag + ">" : v;
    return "<" + (tag || "span") + ' data-p="' + p + '" contenteditable="plaintext-only" spellcheck="true" class="ed' + (cls ? " " + cls : "") + '">' + v + "</" + (tag || "span") + ">";
  }
  /* Lista de textos cortos (cintas, etiquetas): una línea editable separada con | */
  function L(p, label) {
    return '<div class="edit-line"><small>' + esc(label) + '</small><span data-p="' + p + '" data-arr="1" contenteditable="plaintext-only" spellcheck="false" class="ed">' + esc(get(p).join(" | ")) + "</span></div>";
  }
  /* Enlace que en modo edición deja de navegar */
  function A(href, cls, inner, blank) {
    if (editing) return '<span class="' + cls + '">' + inner + "</span>";
    return '<a class="' + cls + '" href="' + esc(href) + '"' + (blank ? ' target="_blank" rel="noopener"' : "") + ">" + inner + "</a>";
  }
  function RM(p, i) {
    return editing ? '<button type="button" class="rm" data-act="rm" data-p="' + p + '" data-i="' + i + '" aria-label="' + esc(UI[lang].remove) + '">×</button>' : "";
  }
  function ADD(p, t) {
    return editing ? '<button type="button" class="add" data-act="add" data-p="' + p + '" data-t="' + t + '">+ ' + esc(UI[lang].add) + "</button>" : "";
  }
  function inp(path, label) {
    var v = get(path);
    return '<label>' + esc(label) + '<input type="text" data-s="' + path + '" value="' + esc(v == null ? "" : v) + '"></label>';
  }

  // Cinta animada: un "medio" repetido + su copia = bucle continuo sin cortes
  function track(items, kind, reverse) {
    var sep = kind === "top" ? "<b>●</b>" : '<span class="dot" aria-hidden="true"></span>';
    var one = items.map(function (t) { return "<span>" + esc(t) + "</span>" + sep; }).join("");
    var half = "", reps = kind === "top" ? 3 : (items.length > 4 ? 2 : 3);
    for (var i = 0; i < reps; i++) half += one;
    return '<div class="track' + (kind === "top" ? " mono" : "") + (reverse ? " rev" : "") + '" aria-hidden="true">' + half + half + "</div>";
  }
  function chips(list) {
    return '<ul class="tags">' + list.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul>";
  }

  /* ---------- idioma ---------- */
  function initialLang() {
    var q = new URLSearchParams(location.search).get("lang");
    if (LANGS.indexOf(q) > -1) return q;
    try { var s = localStorage.getItem("lang"); if (LANGS.indexOf(s) > -1) return s; } catch (e) {}
    return (navigator.language || "en").toLowerCase().indexOf("es") === 0 ? "es" : "en";
  }
  var lang = initialLang();

  /* ---------- borrador (solo en modo edición) ---------- */
  if (editing) {
    try {
      var raw = localStorage.getItem(DRAFT_KEY);
      if (raw) {
        var d = JSON.parse(raw);
        if (d && d.en && d.es && d.config) { SITE.en = d.en; SITE.es = d.es; SITE.config = d.config; cfg = SITE.config; }
      }
    } catch (e) {}
  }
  var saveTimer = null;
  function saveDraft() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(function () {
      try { localStorage.setItem(DRAFT_KEY, JSON.stringify({ en: SITE.en, es: SITE.es, config: SITE.config })); status(UI[lang].saved); } catch (e) {}
    }, 400);
  }
  function status(t) { var s = document.getElementById("st"); if (s) s.textContent = t; }

  /* ---------- fragmentos fijos ---------- */
  var GHERKIN =
    '<span class="k">Feature:</span> Online store purchase\n' +
    '  <span class="k">Scenario:</span> Order with stock\n' +
    '    <span class="k">Given</span> a product with stock\n' +
    '    <span class="k">When</span>  the customer confirms payment\n' +
    '    <span class="k">Then</span>  the order is recorded\n' +
    '    <span class="k">And</span>   the stock drops by 1';
  var SQL =
    '<span class="c">-- Which products are out of stock?</span>\n' +
    '<span class="k">SELECT</span> ProductName,\n' +
    '       UnitsInStock,\n' +
    '       UnitPrice\n' +
    '<span class="k">FROM</span>   Products\n' +
    '<span class="k">WHERE</span>  UnitsInStock = <span class="n">0</span>;';
  var ICON_LI = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect width="24" height="24" rx="5" fill="#60a5fa"/><g fill="#0f172a"><circle cx="7" cy="7" r="1.7"/><path d="M5.5 9.5h3v9h-3z"/><path d="M10.5 9.5h2.9v1.3c.5-.9 1.6-1.5 2.9-1.5 2.4 0 3.2 1.5 3.2 3.8v5.4h-3v-4.8c0-1.1-.3-1.8-1.3-1.8-1.1 0-1.7.8-1.7 1.9v4.7h-3z"/></g></svg>';
  var ICON_GH = '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"/></svg>';

  /* ---------- render ---------- */
  function render() {
    D = SITE[lang];
    var t = D, u = UI[lang];
    var h = t.hero;
    var gh = safeUrl(cfg.github), li = safeUrl(cfg.linkedin);

    document.documentElement.lang = t.htmlLang;
    document.title = (editing ? "✎ " : "") + t.pageTitle;
    document.body.classList.toggle("editing", editing);
    var md = document.querySelector('meta[name="description"]');
    if (md) md.setAttribute("content", t.metaDescription);

    nav.setAttribute("aria-label", t.menuLabel);
    nav.innerHTML = IDS.map(function (id) {
      var k = id === "contact" ? "contact" : id;
      return editing
        ? '<span class="nl">' + T("nav." + k) + "</span>"
        : '<a href="#' + id + '" data-id="' + id + '">' + esc(t.nav[k]) + "</a>";
    }).join("");
    langBtn.textContent = t.switchTo;
    langBtn.setAttribute("aria-label", t.switchLabel);

    var html = "";

    /* panel de links (solo edición) */
    if (editing) {
      html += '<div class="wrap panel"><div><h4>' + esc(u.linksTitle) + "</h4>" +
        inp("@email", u.email) + inp("@github", u.github) + inp("@linkedin", u.linkedin) + inp("@tiendaNube", u.store) +
        "</div></div>";
    }

    /* franja + hero */
    html += editing
      ? '<div class="wrap">' + L("topBand", u.band) + "</div>"
      : '<div class="band-top">' + track(t.topBand, "top") + "</div>";

    html +=
      '<section class="hero"><div class="wrap">' +
      '<p class="kicker">' + T("hero.kicker") + "</p>" +
      '<p class="hi">' + T("hero.hi") + "</p>" +
      '<h1 class="big-name">' + T("hero.name") + "</h1>" +
      '<p class="tagline">' + T("hero.tagline") + "</p>" +
      '<p class="studying">' + T("hero.studying") + "</p>" +
      '<div class="btns">' +
      A("#contact", "btn fill", T("hero.talk")) +
      A(gh, "btn", "GitHub ↗", true) +
      A(li, "btn", "LinkedIn ↗", true) +
      "</div>" +
      '<div class="avail">' + T("hero.available") + "</div></div></section>";

    html += editing
      ? '<div class="wrap">' + L("toolsBand", u.band) + "</div>"
      : '<div class="band-big">' + track(t.toolsBand, "big", true) + "</div>";

    /* frase que rota */
    html += '<section class="say"><div class="wrap"><h2>' + T("say.lead") +
      (editing ? "" : ' <span class="rot" id="rot" aria-live="off">' + esc(t.say.words[0]) + "</span>") + "</h2>" +
      (editing ? L("say.words", u.band) : "") + "</div></section>";

    /* sobre mí */
    var a = t.about;
    html += '<section class="sec" id="about"><div class="wrap grid"><p class="mono label">' + T("about.label") + "</p><div>" +
      '<h2 class="title">' + T("about.title") + '</h2><div class="prose">';
    a.paragraphs.forEach(function (_, i) { html += '<p class="rel">' + RM("about.paragraphs", i) + T("about.paragraphs." + i) + "</p>"; });
    html += "</div>" + ADD("about.paragraphs", "para") + '<div class="facts">';
    a.facts.forEach(function (_, i) {
      html += '<div class="fact"><span class="mono">' + T("about.facts." + i + ".label") + "</span><span>" + T("about.facts." + i + ".value") + "</span></div>";
    });
    html += "</div></div></div></section>";

    /* cómo trabajo */
    var w = t.how;
    html += '<section class="sec soft" id="how"><div class="wrap grid"><p class="mono label">' + T("how.label") + "</p><div>" +
      '<h2 class="title">' + T("how.title") + "</h2>" +
      '<div class="codes">' +
      '<figure class="code-card"><pre><code>' + GHERKIN + '</code></pre><figcaption class="mono">' + T("how.gherkinCaption") + "</figcaption></figure>" +
      '<figure class="code-card"><pre><code>' + SQL + '</code></pre><figcaption class="mono">' + T("how.sqlCaption") + "</figcaption></figure>" +
      '</div><div class="skills">';
    w.skills.forEach(function (_, i) {
      html += '<div class="skill rel">' + RM("how.skills", i) + "<h4>" + T("how.skills." + i + ".title") + "</h4><p>" + T("how.skills." + i + ".text") + "</p></div>";
    });
    html += "</div>" + ADD("how.skills", "skill") + "</div></div></section>";

    /* 6 razones */
    var y = t.why;
    html += '<section class="sec" id="why"><div class="wrap"><p class="mono label" style="margin-bottom:14px">' + T("why.label") + "</p>" +
      '<h2 class="title">' + T("why.title") + '</h2><div class="reasons">';
    y.items.forEach(function (r, i) {
      var b = "why.items." + i;
      html += '<article class="reason"><header><span class="num' + (r.dark ? " dark" : "") + '">' + r.n + "</span><h3>" + T(b + ".title") + "</h3></header>" +
        '<div class="lines">';
      r.lines.forEach(function (_, j) {
        html += "<p><strong>" + T(b + ".lines." + j + ".k") + "</strong> " + T(b + ".lines." + j + ".v") + "</p>";
      });
      html += "</div>" + (editing ? L(b + ".tags", u.tags) : chips(r.tags)) + "</article>";
    });
    html += "</div></div></section>";

    /* trayectoria */
    var bg = t.background;
    html += '<section class="sec soft" id="background"><div class="wrap grid"><p class="mono label">' + T("background.label") + "</p><div>";
    html += '<h3 class="sub">' + T("background.experienceTitle") + "</h3>";
    bg.jobs.forEach(function (j, i) {
      var b = "background.jobs." + i;
      html += '<article class="job rel">' + RM("background.jobs", i) + '<div class="when mono">' + T(b + ".date") +
        "<span>" + T(b + ".duration") + "</span><span>" + T(b + ".type") + "</span></div><div>" +
        "<h4>" + T(b + ".title") + '</h4><p class="org">' + T(b + ".org") + "</p><ul>";
      j.bullets.forEach(function (_, k) { html += '<li class="rel">' + RM(b + ".bullets", k) + T(b + ".bullets." + k) + "</li>"; });
      html += "</ul>" + ADD(b + ".bullets", "bullet");
      if (editing || j.note) html += '<p class="note">' + (editing ? '<small class="mono">' + esc(u.note) + "</small>" : "") + T(b + ".note") + "</p>";
      html += "</div></article>";
    });
    html += ADD("background.jobs", "job");
    html += '<h3 class="sub edu-head">' + T("background.educationTitle") + "</h3>";
    bg.education.forEach(function (e, i) {
      var b = "background.education." + i;
      html += '<article class="job rel">' + RM("background.education", i) + '<div class="when mono">' + T(b + ".date") +
        (editing || e.status ? "<span>" + T(b + ".status") + "</span>" : "") + "</div><div>" +
        "<h4>" + T(b + ".title") + '</h4><p class="org">' + T(b + ".org") + "</p></div></article>";
    });
    html += ADD("background.education", "edu");
    html += "</div></div></section>";

    /* proyectos */
    var p = t.projects;
    cfg.projectLinks = cfg.projectLinks || {};
    html += '<section class="sec" id="projects"><div class="wrap grid"><p class="mono label">' + T("projects.label") + "</p><div>";
    html += '<h2 class="title">' + T("projects.title") + "</h2>";
    p.items.forEach(function (it, i) {
      var b = "projects.items." + i;
      if (!it.id) it.id = "p" + Date.now() + i;
      var inner;
      if (editing) {
        inner = '<div class="proj rel">' + RM("projects.items", i) + "<div><h4>" + T(b + ".name") + "</h4>" +
          L(b + ".tags", u.tags) +
          '<div class="edit-line"><small>' + esc(u.status) + "</small>" + T(b + ".status") + "</div></div>" +
          "<p>" + T(b + ".text") + "</p><span></span></div>" +
          '<label class="fld">' + esc(u.url) + '<input type="text" data-s="@projectLinks.' + it.id + '" value="' + esc(cfg.projectLinks[it.id] || "") + '"></label>';
        html += '<div class="projwrap">' + inner + "</div>";
      } else {
        var url = safeUrl(cfg.projectLinks[it.id] || cfg.github);
        var tg = (it.status ? '<li class="live">' + esc(it.status) + "</li>" : "") + it.tags.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("");
        html += '<a class="proj" href="' + esc(url) + '" target="_blank" rel="noopener"><div><h4>' + esc(it.name) +
          '</h4><ul class="tags">' + tg + "</ul></div><p>" + esc(it.text) + '</p><span class="arrow" aria-hidden="true">↗</span></a>';
      }
    });
    html += ADD("projects.items", "project");
    var store = safeUrl(cfg.tiendaNube);
    html += '<p class="foot-note">' + T("projects.footPrefix") +
      (editing ? T("projects.footGithub") : '<a href="' + esc(gh) + '" target="_blank" rel="noopener">' + esc(p.footGithub) + "</a>") +
      T("projects.footMiddle") +
      (editing || !store ? T("projects.footStore") : '<a href="' + esc(store) + '" target="_blank" rel="noopener">' + esc(p.footStore) + "</a>") +
      T("projects.footSuffix") + "</p>";
    html += "</div></div></section>";

    /* franja + oportunidad */
    html += editing
      ? '<div class="wrap">' + L("marquee", u.band) + "</div>"
      : '<div class="band-big alt">' + track(t.marquee, "big") + "</div>";
    var o = t.opportunity;
    html += '<section class="opp"><div class="wrap"><h2>' + T("opportunity.title") + '</h2><p class="p1">' + T("opportunity.p1") + '</p><p class="p2">' + T("opportunity.p2") + "</p>" +
      '<div class="facts">';
    o.facts.forEach(function (_, i) {
      html += '<div class="fact"><span class="mono">' + T("opportunity.facts." + i + ".label") + "</span><span>" + T("opportunity.facts." + i + ".value") + "</span></div>";
    });
    html += "</div></div></section>";

    /* cierre */
    var c = t.contact;
    html += '<section class="cta" id="contact"><div class="wrap">' +
      '<span class="pill">' + T("contact.pill") + "</span>" +
      "<h2>" + T("contact.title") + '</h2><p class="sub">' + T("contact.sub") + "</p>" +
      '<div class="mailrow">' + A("mailto:" + cfg.email, "mail", esc(cfg.email)) +
      '<button class="btn sm" id="copy" type="button">' + esc(c.copy) + "</button></div>" +
      '<div class="btns">' + A("mailto:" + cfg.email, "btn fill", T("contact.send")) +
      A(li, "btn", ICON_LI + esc(cfg.linkedinLabel || "LinkedIn"), true) +
      A(gh, "btn", ICON_GH + esc(cfg.githubLabel || "GitHub"), true) + "</div>" +
      "</div></section>";

    html += '<footer><div class="wrap foot mono"><span>' + T("footer.left") + "</span><span>" + T("footer.right") + "</span></div></footer>";

    var sy = window.scrollY;
    main.innerHTML = html;
    window.scrollTo(0, sy);   // se queda exactamente donde estaba

    if (editing) {
      var eds = main.querySelectorAll("[contenteditable]");
      for (var q = 0; q < eds.length; q++) {
        if (eds[q].contentEditable !== "plaintext-only") eds[q].contentEditable = "true";
      }
      renderBar();
    }
    bindCopy(c);
    watchSections();
    startRot(t.say.words);
  }

  function renderBar() {
    var bar = document.getElementById("bar");
    if (!bar) { bar = document.createElement("div"); bar.id = "bar"; bar.className = "bar"; bar.setAttribute("role", "region"); document.body.appendChild(bar); }
    var u = UI[lang];
    bar.setAttribute("aria-label", "Editor");
    bar.innerHTML = '<span class="hint">' + esc(u.hint) + '</span><span class="st" id="st" role="status"></span>' +
      '<button type="button" data-act="discard">' + esc(u.discard) + '</button>' +
      '<button type="button" class="go" data-act="download">' + esc(u.download) + "</button>";
  }

  /* ---------- frase que rota ---------- */
  function startRot(words) {
    if (rotTimer) { clearInterval(rotTimer); rotTimer = null; }
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (editing || reduce || words.length < 2) return;
    var i = 0;
    rotTimer = setInterval(function () {
      var r = document.getElementById("rot");
      if (!r) return;
      r.classList.add("out");
      setTimeout(function () {
        i = (i + 1) % words.length;
        r.textContent = words[i];
        r.classList.remove("out");
      }, 360);
    }, 2800);
  }

  /* ---------- copiar email ---------- */
  function bindCopy(c) {
    var btn = document.getElementById("copy");
    if (!btn) return;
    btn.addEventListener("click", function () {
      function done() {
        btn.textContent = c.copied;
        setTimeout(function () { btn.textContent = c.copy; }, 1800);
      }
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(cfg.email).then(done, fallback);
      } else fallback();
      function fallback() {
        var ta = document.createElement("textarea");
        ta.value = cfg.email; ta.style.position = "fixed"; ta.style.opacity = "0";
        document.body.appendChild(ta); ta.select();
        try { document.execCommand("copy"); done(); } catch (e) {}
        document.body.removeChild(ta);
      }
    });
  }

  /* ---------- resalta la sección activa en el menú ---------- */
  function watchSections() {
    if (observer) observer.disconnect();
    if (editing || !("IntersectionObserver" in window)) return;
    observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        nav.querySelectorAll("a").forEach(function (a) {
          a.classList.toggle("on", a.getAttribute("data-id") === en.target.id);
        });
      });
    }, { rootMargin: "-35% 0px -60% 0px" });
    IDS.forEach(function (id) {
      var el = document.getElementById(id); if (el) observer.observe(el);
    });
  }

  /* ---------- descargar content.js actualizado ---------- */
  function download() {
    var txt =
      "/* CONTENIDO DEL PORTFOLIO. Archivo generado desde el modo edición (?edit).\n" +
      "   Para actualizar el sitio: subí este archivo a GitHub reemplazando el content.js anterior.\n" +
      "   También podés editarlo a mano: config = links y email, en = inglés, es = español. */\n\n" +
      "window.SITE = " + JSON.stringify({ config: SITE.config, en: SITE.en, es: SITE.es }, null, 2) + ";\n";
    var blob = new Blob([txt], { type: "text/javascript;charset=utf-8" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "content.js";
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1500);
    status(UI[lang].downloaded);
  }

  /* ---------- eventos ---------- */
  langBtn.addEventListener("click", function () {
    lang = lang === "en" ? "es" : "en";   // mismo sitio, misma pestaña
    try { localStorage.setItem("lang", lang); } catch (e) {}
    if (window.history && history.replaceState) {
      var u = new URL(location.href); u.searchParams.set("lang", lang);
      history.replaceState(null, "", u.pathname + u.search + u.hash);
    }
    render();
  });

  if (editing) {
    document.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-act]") : null;
      if (!b) return;
      var act = b.getAttribute("data-act"), p = b.getAttribute("data-p");
      if (act === "download") download();
      else if (act === "discard") {
        if (window.confirm(UI[lang].confirmDiscard)) {
          try { localStorage.removeItem(DRAFT_KEY); } catch (er) {}
          location.reload();
        }
      } else if (act === "rm") { get(p).splice(+b.getAttribute("data-i"), 1); saveDraft(); render(); }
      else if (act === "add") {
        var tpl = clone(TPL[lang][b.getAttribute("data-t")]);
        if (b.getAttribute("data-t") === "project") tpl.id = "p" + Date.now();
        get(p).push(tpl); saveDraft(); render();
      }
    });
    main.addEventListener("input", function (e) {
      var el = e.target, p = el.getAttribute && el.getAttribute("data-p"), s = el.getAttribute && el.getAttribute("data-s");
      if (p) {
        var txt = el.textContent;
        if (el.getAttribute("data-arr")) set(p, txt.split("|").map(function (x) { return x.trim(); }).filter(Boolean));
        else set(p, txt);
      } else if (s) set(s, el.value);
      saveDraft();
    });
    main.addEventListener("keydown", function (e) {
      if (e.key === "Enter" && e.target.getAttribute && e.target.getAttribute("data-p")) e.preventDefault();
    });
    nav.addEventListener("input", function (e) {
      var p = e.target.getAttribute && e.target.getAttribute("data-p");
      if (p) { set(p, e.target.textContent); saveDraft(); }
    });
    nav.addEventListener("keydown", function (e) {
      if (e.key === "Enter") e.preventDefault();
    });
  }

  render();
})();
